
function updateSklills(name, skill){
console.log(name);
console.log(skill);
}

function updateStudents(){

}

function addition(a, b){
var c = a + b;
console.log(c);
// kdjgkdjkgjf
return 'Ekta';
return c;
console.log("jksdhkjshsjks");
}

updateSklills('Suraj', 'Angular');

var res = addition(20,20);
console.log(res);


updateSklills('Sameer', 'Python');

var res2 = addition(50,50);
console.log(res2);


// DOM :


