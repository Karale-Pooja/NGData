"use strict";

console.log(a);
var a = 10;

// console.log(b);

// let b = 10;

// console.log(c);

// const c = 10;

var d = 10;
var d = 22;

let e = 20;
// let e = 45;

console.log(d);


f = 10;

console.log(f);