var first = 20;
var second = 10;
var third = 40;



// second += first;
//     second = second + first;
//      second= 10 + 20
// console.log(second); 30
// console.log(first); 20



let x = 1, 
    y = 2;
x += y;
console.log(x);