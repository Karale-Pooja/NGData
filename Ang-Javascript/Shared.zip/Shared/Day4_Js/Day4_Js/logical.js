var first = true;

var second = false;
// logical AND Operator.
console.log(first && second); // false

// logical OR Operator.
console.log(first || second); // true

// logical NOT Operator.
console.log(!first); // false



