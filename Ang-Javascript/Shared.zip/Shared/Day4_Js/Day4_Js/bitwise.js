var first = 3; // 0011
var second = 2; // 0010


console.log(first & second); //2
console.log(first | second); // 3

