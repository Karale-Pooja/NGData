// var test1;

// console.log(test1);
// console.log(typeof(test1));

// // console.log(test2);

// var test3 = null;
// console.log(null);
// console.log(typeof(test3));
// console.log(test3.valueOf());

var test4 = null + 5 ;
// var test5 = null  + true;
// var test5 = null  + "Hello";

console.log(test4 );
console.log(test5 );


