let data3 = "ANG Software";

sessionStorage.setItem('compname', data3);

// sessionStorage.setItem(key, value);

var result = sessionStorage.getItem('compname');

console.log(result);

// all methods of session storage are same as of localstorage.
