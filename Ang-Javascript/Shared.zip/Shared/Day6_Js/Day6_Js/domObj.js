
console.log("Hell this is external JS file");

function onSubmitButton(firstName, lastName){
    console.log("this is an first event");
    console.log( firstName, lastName);
}