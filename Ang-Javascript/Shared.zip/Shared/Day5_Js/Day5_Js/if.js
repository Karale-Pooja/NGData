
var first = 25;

if(first >= 25){
    console.log("Selected number is equal to or greater than 25");

}

console.log("This is the code out of control statement");


var test1 = 41;
var test2 = "Hello";

if(test1 == 42){

    if(test2 =="Hello"){
        console.log("Second condition will be executed");
        
    }

}

if(!(test1 ==41) && test2=="Hello"){
    console.log("Both conditions are true");
}

if(test1 ==41 || test2=="Hello"){
    console.log("Both conditions are true");
}
