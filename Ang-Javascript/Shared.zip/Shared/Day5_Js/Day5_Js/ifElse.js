
var first = 22;

if(first > 21){
    console.log("Selected value is greater than 22");
} else {
    console.log("Selected number is not greater than 22");
}


if(first == 24){
    console.log("Selected value is 24");
} 
else if(first == 23){
    console.log("Selecyed value is 23");
} 
else if(first == 22){
    console.log("Selected value is 22")
} else{
    console.log("Value is not matching");
}