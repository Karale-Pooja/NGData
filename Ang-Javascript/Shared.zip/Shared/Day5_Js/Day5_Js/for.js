var test1 = 10;

for(let i = 0; i <= test1; ++i ){
    console.log(i);
}

