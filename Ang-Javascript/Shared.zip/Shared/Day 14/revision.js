var x = 7;

function add(y){
    var res = 10 + y;

    return res;
}

let addRes = add(5);
// let addRes2 = add(x);

console.log(typeof(add));

// array
// object
// function


var a = {};
var b = {};

console.log(a==b); // false
console.log(a === b); // false

var c = 10;
var d = 10;

console.log(c == d); // true
console.log(c === d); // true


console.log(z);
z = 10;
console.log(z);
var z;
z ="15";
