
var first = "ANG";
var second = "Pune";
var third = '10';
var fourth = 10;
// ==, !=, ===, >, < , >=, <=

console.log(first == second); // false

console.log(first != second);// true

console.log(third == fourth); // true
 
console.log(third === fourth); // false