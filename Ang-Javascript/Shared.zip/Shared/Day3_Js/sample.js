
console.log("This is an external JS file");

// document.write("This will show on browser");
// single line comment

/*
document.write("This will show on browser");
document.write("This will show on browser");
document.write("This will show on browser");

*/
console.log("End of multi line comment");
// multi line comment