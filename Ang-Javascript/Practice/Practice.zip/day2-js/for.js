for(var a=1;a<=10;a++)
{
    console.log(a);
}                          //10times got "1"