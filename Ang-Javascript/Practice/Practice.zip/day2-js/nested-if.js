var a = 22;
if( a>15)
{
    console.log("a is greater than 15");
}
if( a>23)
{
    console.log("a is greater than 20");
}