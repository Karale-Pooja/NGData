let age = 9;
if (age < 8) {
    console.log("You are child")//
}
else if (age < 5 && age > 10) {
    console.log("You are not eligible")
}

else if (age >= 15 && age <7 );

else
 {console.log("You can't apply")
}
    
    //
