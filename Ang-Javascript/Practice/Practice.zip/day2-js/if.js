var a = 10;
var b =10;
if(a==10);
{
    console.log("This is true");
}                                //"This is true"

var a = 10;
var b =5;
if(a==10);
{
    console.log("This is true");
}                                  //blank
