
// var day = new Date().getDay();

// console.log(day);

// switch(day){

//     default:
//     day = 'Sat';
//     break;

//     case 0:
//     day = 'Sunday';
//     break;

//     case 1:
//     day = 'Monday';
//     break;

//     case 2:
//     day = 'Tue';
//     break;

//     case 3:
//     day = 'Wed';
//     break;

//     case 4:
//     day = 'Thr';
//     break;

//     case 5:
//     day = 'Fri';
//     break;



// }

// console.log(day);// day6 sat

var age = 18;
switch (age) {
    case 1:
        age=14
        console.log("you are 14");
        break;

    case 2:
        age=15
        console.log("you are 15");
        break;

    case 3:
        age=10
        console.log("you are child");
        break;

    default:
        console.log("you are 18")
        break;

}