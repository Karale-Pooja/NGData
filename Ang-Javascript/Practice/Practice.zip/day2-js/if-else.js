var x =55;
if(x > 65)
{
console.log("x is Greater")
}
else{
    console.log("x is smaller")
}                              //"x is smaller"