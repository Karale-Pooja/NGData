var i=0;
while(i<5){
    console.log("current value of i:"+i);
i++;
    
}                                  //current value of i:0
                                    //   current value of i:1
                                    //       current value of i:2
                                    //       current value of i:3
                                    //        current value of i:4
