
// var count2 = 1;

// do{
//     count2++;
//     console.log("This code will be executed by default");
    

// }
// while(count2 < 5);
// This code will be executed by default
// This code will be executed by default
// This code will be executed by default
// This code will be executed by default

var a = 1;
do{
    a++;
    console.log("hi")
}
while(a<7);