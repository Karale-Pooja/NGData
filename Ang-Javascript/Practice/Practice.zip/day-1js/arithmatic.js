// addition
var a = 2;
var b = 3;
var c = a + b;
console.log(c); //5
 
// subtraction
var a = 2;
var b = 3;
var c = a - b;
console.log(c); //-1

// multiplication
var a = 2;
var b = 3;
var c = a * b;
console.log(c); //6
 
// division
var a = 6;
var b = 2;
var c = a / b;
console.log(c);  //3

// modulus
var a = 12;
var b = 2;
var c = a % b;
console.log(c); //0

// exponential
var a = 2;
var b = 3;
var c = a ** b;
console.log(c); //8

// increment
var a = 2;
var b = 3;
a++;
console.log(a+b); //6

//  decrement
var a = 5;
var b = 2;
a--;
console.log(a-b); //2
