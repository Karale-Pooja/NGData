// == 
var a = 10;
var b = 20;
console.log(a==b); //false 
 
var a = 10;
var b = 10;
console.log(a==b); //true

// ===
var a = 10;
var b = 20;
console.log(a===b); //false 

var a = 10;
var b = 10;
console.log(a===b); //true

var a = 10;
var b = '10';
console.log(a===b); //false

// !=
var a = 10;
var b = '20';
console.log(a!=b); //true

var a = 20;
var b = '20';
console.log(a!=b); //false

// !==

var a = 10;
var b = '20';
console.log(a!==b); //true

var a = '20';
var b = '20';
console.log(a!==b); //false

// >
var a = 10;
var b = '20';
console.log(a>b); //false

var a = 60;
var b = '10';
console.log(a>b); //true

// >=
var a = 80;
var b = '20';
console.log(a>=b); //true

var a = 10;
var b = '20';
console.log(a>=b); //false

// <=
var a = 50;
var b = '20';
console.log(a<=b); //false

var a = 10;
var b = '50';
console.log(a<=b); //true







 
 
 
 
 
 
 
 
 
 