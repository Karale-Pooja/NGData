// assignment operator:add
var a = 6;
var b = 3;
a+=b;    //compound (is nothing but a=a+b)
console.log(a)             //9

// assignment operator:sub
var a = 6;
var b = 3;
a-=b;    //compound (is nothing but a=a-b)
console.log(a)             //3

// assignment operator:mul
var a = 6;
var b = 3;
a*=b;    //compound (is nothing but a=a*b)
console.log(a)             //18

// assignment operator:div
var a = 6;
var b = 3;
a/=b;    //compound (is nothing but a=a/b)
console.log(a)             //2


