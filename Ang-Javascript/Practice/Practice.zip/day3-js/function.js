function Intro ()
{
    console.log("I am teacher");
console.log('<br>');

console.log("My name is Radha");
console.log('<br>');

}
Intro();