a = 10;
console.log(a);

b = a;
console.log(b);

var c = "Sameer";
console.log(c);

let d = true;
console.log(d);

a = 50;
console.log(a);

// var var = "Hello";

var _123 = "hi";

var abc = "Hello abc";

var ABC = "This is ABC";

const name = "V id y a";

console.log(name);

// name = "Suvarna";

// const a = 70;

// b = a + 10;
// console.log(b);

let e = "Kaveri"

var $123 = "Hi";
console.log($123);




