
var a = 16;
var res = (a==15) ? 'Number is 15' : 'Number is not 15';
// var res = condtion ? option1 : option2;

console.log(res);