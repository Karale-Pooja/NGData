var test1 = (a)=>{
    console.log(a);
}

var test2 = (a)=> console.log(a);

// console.log(b);

// const b =10;

// c = 10;

// console.log(c);

let c;

abc();


function abc(){
console.log("Hello ABC");
}

var test3 = 10;
test3 = "Hello JS";

console.log(test3);

