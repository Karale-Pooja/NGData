
var count = 1;

while(count <= 10){
    console.log(count);
    count ++;
}

var count2 = 1;

do{
    count2++;
    console.log("This code will be executed by default");
    

}
while(count2 < 5);
