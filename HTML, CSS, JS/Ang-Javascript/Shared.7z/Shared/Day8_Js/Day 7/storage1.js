// var temp = 50;
// console.log(temp);

// document.mycookie1 = "name: value; expires: expiry Date"; // cookie syntax

document.cookie2 = "name: Claritech Solution; expires: Fri Aug 12 2022 08:14:48 GMT+0530 (India Standard Time)";

console.log(document.cookie2);